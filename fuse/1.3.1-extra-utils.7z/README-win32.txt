The Fuse utilities for Windows 1.3.1
====================================

This is a binary distribution of the Fuse utilities for Windows.  For
an introduction to fuse-utils, see README.txt.  For more detailed 
documentation, read the manuals available as HTML files.

Requirements
------------

Windows 2000/XP/Vista/7/8/10.

Libraries
---------

These binaries were built with:

    audiofile 0.3.6
    bzip2 1.0.6
    libgcrypt 1.6.6
    libgpg-error 1.24
    libjpeg-turbo 1.5.0
    libpng 1.6.24
    libspectrum 1.3.1
    libstdc++6 5.4.0
    win-iconv 0.0.6
    zlib 1.2.8

See LICENSES.txt for copyright and license details.

Notes
-----

You can extend the output formats supported by fmfconv with FFmpeg:
https://ffmpeg.zeranoe.com/builds/win32/static/ffmpeg-latest-win32-static.7z

fmfconv is based in part on the work of the Independent JPEG Group.

Compiled by Sergio Baldoví <serbalgi@gmail.com>
6th November, 2016
